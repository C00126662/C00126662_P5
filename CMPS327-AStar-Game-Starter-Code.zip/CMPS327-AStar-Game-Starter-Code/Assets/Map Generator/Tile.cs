﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MapGen;

public class Tile : MonoBehaviour,IComparable<Tile>
{
    public MapTile mapTile;
    public int indexX;
    public int indexY;
    public bool isPassable;
    public bool isStart { get; private set; }
    public bool isGoal { get; private set; }
    public List<Tile> Adjacents { get; private set; }

    private void Awake()
    {
        Adjacents = new List<Tile>();
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    // returns true if other tile is diagonal to this tile
    // tile is diagonal if |∆indexX| = 1 && |∆indexY| = 1
    public bool IsDiagonalTo(Tile other)
    {
        return Mathf.Abs(other.indexX - indexX) == 1 && Mathf.Abs(other.indexY - indexY) == 1;
    }

    public void FillFromMapTile(MapTile _mapTile)
    {
        mapTile = _mapTile;
        indexX = mapTile.X;
        indexY = mapTile.Y;
        isPassable = mapTile.Walkable;
        isStart = mapTile.IsStart;
        isGoal = mapTile.IsGoal;
    }

    public void AddAdjacentTile(Tile tile)
    {
        if (tile.isPassable) Adjacents.Add(tile);
    }

    public int CompareTo(Tile other)
    {
        Debug.Log("Comparing " + this + " and " + other);
        int x1 = indexX, y1 = indexY;
        int x2 = other.indexX, y2 = other.indexY;
        if (x1.CompareTo(x2) != 0)
        {
            return x1.CompareTo(x2);
        }
        return y1.CompareTo(y2);
    }

    public bool Equals(Tile other)
    {
        return indexX == other.indexX && indexY == other.indexY;
    }

    public static float TileDistance(Tile t1, Tile t2)
    {
        float x = Mathf.Abs(t2.indexX - t1.indexX);
        float y = Mathf.Abs(t2.indexY - t1.indexY);
        return Mathf.Sqrt(x * x + y * y);
    }

    public override string ToString()
    {
        return "( " + indexX + ", " + indexY + " )";
    }
}
